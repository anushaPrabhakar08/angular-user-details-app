import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { FormControl, Validators, FormGroup } from '@angular/forms';
import { CommonService } from '../common.service';
import { Router, ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-user-add-member',
  templateUrl: './user-add-member.component.html',
  styleUrls: ['./user-add-member.component.css']
})
export class UserAddMemberComponent implements OnInit {
  addMemberform: FormGroup;

  constructor(private newService: CommonService,
    private router: Router,
    private route: ActivatedRoute) {
    this.userCode = this.route.snapshot.paramMap.get('id');
    this.userEmail = this.route.snapshot.paramMap.get('userid');
  }


  selectRung = new FormControl(null, [Validators.required]);
  valbutton = "Save";
  userCode;
  userEmail;
  userid = new FormControl('');

  public hasError = (controlName: string, errorName: string) => {
    return this.addMemberform.controls[controlName].hasError(errorName);
  }

  ngOnInit() {
    this.addMemberform = new FormGroup({
      firstName: new FormControl('', [Validators.required, Validators.maxLength(60)]),
      lastName: new FormControl('', [Validators.required, Validators.maxLength(60)]),
      age: new FormControl('', [Validators.required, Validators.maxLength(3)]),
      email: new FormControl('', [Validators.required, Validators.maxLength(10)]),
    });
  }
  
  emailFormControl = new FormControl('', [
    Validators.email
  ]);

  onMemberSave(member, invalid: Boolean) {
    console.log(member);
    //debugger;
    member.mode = this.valbutton;
    console.log(member.userid)
    member.userid = this.newService.getCurrentUser()._id;
    console.log(member.userid)
    this.newService.saveMember(member)
      .subscribe(response => {
        //debugger;
        const link = '/userdashboard/family-members';
        this.router.navigate([link]);
      })

  }


}
