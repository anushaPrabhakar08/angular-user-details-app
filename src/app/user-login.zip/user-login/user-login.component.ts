import { Component, OnInit } from '@angular/core';
import { FormControl, Validators, FormGroup } from '@angular/forms';
import { CommonService } from '../common.service';
import { Router } from '@angular/router';
import { Iproduct } from '../iproduct';

@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class UserLoginComponent implements OnInit {
  userform: FormGroup;
  constructor(private newService: CommonService,
    private router: Router) { }

  public hasError = (controlName: string, errorName: string) => {
    return this.userform.controls[controlName].hasError(errorName);
  }
  Repdata;
  valbutton = "Save";
  localstorage = localStorage;

  email = new FormControl('', [Validators.required, Validators.email]);

  getErrorMessage() {
    return this.email.hasError('required') ? 'You must enter a value' :
      this.email.hasError('email') ? 'Not a valid email' :
        '';
  }

  ngOnInit() {
    this.userform = new FormGroup({
      firstName: new FormControl('', [Validators.required, Validators.maxLength(60)]),
      lastName: new FormControl('', [Validators.required, Validators.maxLength(60)]),
      password: new FormControl('', [Validators.required, Validators.maxLength(10)]),
      email: new FormControl('', [Validators.required, Validators.maxLength(10)]),
    });
  }

  onSignin(user, invalid: Boolean) {
    user.mode = this.valbutton;
    this.newService.saveUser(user)
      .subscribe(response => {
        this.localstorage.setItem('currentUser', JSON.stringify(response));
        // const link = `userdashboard/${response["_id"]}/${response["firstName"]}`;
        const link = '/userdashboard/family-members';
        this.router.navigate([link]);
      });
  }
}
